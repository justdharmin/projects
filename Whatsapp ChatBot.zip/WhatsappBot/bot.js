const { makeWASocket, useMultiFileAuthState } = require("@whiskeysockets/baileys");
const fs = require("fs");

let userData = {}; // Store user details persistently
const allowedUser = "60165316079@s.whatsapp.net"; // Allowed user's WhatsApp number in JID format
const humanAgent = "60194653282@s.whatsapp.net"; // Agent's WhatsApp number in JID format
let botStartTime = Date.now(); // Store bot start time

// Load responses from responses.txt
const responsesFile = "responses.txt";
const responses = {};

if (fs.existsSync(responsesFile)) {
    const lines = fs.readFileSync(responsesFile, "utf-8").split("\n");
    lines.forEach(line => {
        const [key, response] = line.split("=");
        if (key && response) responses[key.trim()] = response.trim().replace(/\\n/g, "\n");
    });
}

async function startBot() {
    console.log("Starting WhatsApp Bot...");

    const { state, saveCreds } = await useMultiFileAuthState("auth_info");
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", (update) => {
        const { connection } = update;
        if (connection === "close") {
            console.log("Connection closed. Reconnecting...");
            startBot();
        } else if (connection === "open") {
            console.log("Connected to WhatsApp!");
        }
    });

    sock.ev.on("messages.upsert", async (message) => {
        const msg = message.messages[0];
        if (!msg.message || msg.key.fromMe) return; // Ignore own messages

        const sender = msg.key.remoteJid;
        if (sender !== allowedUser && sender !== humanAgent) {
            console.log(`Ignoring message from unauthorized sender: ${sender}`);
            return;
        }

        const messageTimestamp = (msg.messageTimestamp || 0) * 1000;
        if (messageTimestamp < botStartTime) return; // Ignore old messages

        const messageType = Object.keys(msg.message)[0];
        const messageContent =
            msg.message.conversation?.trim().toLowerCase() ||
            msg.message[messageType]?.text?.trim().toLowerCase() ||
            "";

        console.log(`Message from ${sender}: ${messageContent}`);

        if (messageContent === "hi") {
            await sock.sendMessage(sender, { text: responses["hi"] || "Hello! How can I assist you today? 😊" });
            return;
        }

        const detailsRegex = /name:\s*(.+)\ncontact number:\s*(.+)\nlocation:\s*(.+)\ncompany:\s*(.+)/i;
        const match = messageContent.match(detailsRegex);

        if (match) {
            const [, name, contact, location, company] = match;
            userData[sender] = { name, contact, location, company, connectedToAgent: false };

            await sock.sendMessage(sender, {
                text: `Thank you, ${name}! 😊\n\nI have saved your details:\n📞 Contact: ${contact}\n📍 Location: ${location}\n🏢 Company: ${company}\n\nPlease select the type of issue you're experiencing:\n\n📶 *Press 1* for *Network Issue.*\n🖥 *Press 2* for *Application Issue.*\n💾 *Press 3* for *Server Issue.*\n❓ *Press 4* for *Other Issues.*`
            });
            return;
        }

        if (["1", "2", "3", "4"].includes(messageContent)) {
            if (!userData[sender]) {
                await sock.sendMessage(sender, { text: "Please provide your details before selecting an issue. 😊" });
                return;
            }

            if (messageContent === "4") {
                userData[sender].connectedToAgent = true;
                await sock.sendMessage(sender, { text: "You are now connected to a live agent. Please hold. ⏳" });
                await sock.sendMessage(humanAgent, { text: `🔔 User ${sender} needs assistance. Please respond.` });
                return;
            }

            let responseMessage = responses[messageContent] || "I'm not sure how to handle that request. 🤔";
            responseMessage = responseMessage.replace("[User Name]", userData[sender].name || "User");

            await sock.sendMessage(sender, { text: responseMessage });
            return;
        }

        if (userData[sender]?.connectedToAgent) {
            await sock.sendMessage(humanAgent, { text: `User (${userData[sender].name}): ${messageContent}` });
            return;
        }

        if (sender === humanAgent) {
            const userJid = Object.keys(userData).find(jid => userData[jid]?.connectedToAgent);
            if (userJid) {
                await sock.sendMessage(userJid, { text: `Agent: ${messageContent}` });
            } else {
                console.log("No active user conversation to forward the message.");
            }
            return;
        }

        let defaultMessage = responses["default"] || "I'm not sure how to respond to that. Can you clarify? 😊";
        defaultMessage = defaultMessage.replace("[User Name]", userData[sender]?.name || "User");

        await sock.sendMessage(sender, { text: defaultMessage });
    });
}

startBot();
